CREATE TABLE BM002PR (
    PRTNO                  VARCHAR2(15),
    PROCS                  VARCHAR2(5),
    PPPRI                  VARCHAR2(1),
    MXASM                  VARCHAR2(7),
    PRPRI                  VARCHAR2(4),
    "GROUP"                VARCHAR2(2),  -- GROUP is a reserved word, so quoted
    MANHR                  VARCHAR2(7),
    MACHR                  VARCHAR2(7),
    DICST                  VARCHAR2(7),
    REGISTERED_AT          DATE,
    REGISTERED_COMPNAME    VARCHAR2(50),
    REGISTERED_COMPCODE    VARCHAR2(50)
);
