CREATE TABLE BT2001R (
    PLANT               VARCHAR2(2),
    HOUSE               VARCHAR2(1),
    PRDCD               VARCHAR2(2),
    CUSCD               VARCHAR2(8),
    PRTNO               VARCHAR2(15),
    PACKG               VARCHAR2(2),
    PRTDS               VARCHAR2(30),
    INVQY               NUMBER(9,0),
    INVAM               NUMBER(13,2),
    RQRQY               NUMBER(9,0),
    RQRAM               NUMBER(13,2),
    DNOID               NUMBER(6,1),
    REGISTERED_AT       DATE,
    REGISTERED_COMPNAME VARCHAR2(50),
    REGISTERED_COMPCODE VARCHAR2(50)
);
