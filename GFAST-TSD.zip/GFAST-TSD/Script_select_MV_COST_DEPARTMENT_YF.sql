select table_name 
from all_tables 
where owner = 'GFAST' 
group by table_name
order by 1

select 'MV_ACL_YF_DCCS' as table_name ,count(*) from GFAST.MV_ACL_YF_DCCS  union

select 'TW_ACL_YF_DCCS' as table_name ,count(*) from GFAST.TW_ACL_YF_DCCS union
select 'TW_ACT_DPRCTN_DTL_YF' as table_name ,count(*) from GFAST.TW_ACT_DPRCTN_DTL_YF union
select 'TW_ACT_EXP_DTL_YF' as table_name ,count(*) from GFAST.TW_ACT_EXP_DTL_YF union
select 'TW_ACT_EXP_JOB_DTL_YF' as table_name ,count(*) from GFAST.TW_ACT_EXP_JOB_DTL_YF union
select 'TW_BUDGET_ACT_SUM_YF' as table_name ,count(*) from GFAST.TW_BUDGET_ACT_SUM_YF union
select 'TW_COST_DEPARTMENT_YF' as table_name ,count(*) from GFAST.TW_COST_DEPARTMENT_YF union
select 'TW_DPRCTN_BUDGET_DTL_YF' as table_name ,count(*) from GFAST.TW_DPRCTN_BUDGET_DTL_YF union
select 'TW_EXP_BUDGET_DTL_YF' as table_name ,count(*) from GFAST.TW_EXP_BUDGET_DTL_YF union
select 'TW_HDCNT_BUDGET_ACT_SUM_YF' as table_name ,count(*) from GFAST.TW_HDCNT_BUDGET_ACT_SUM_YF union
select 'TW_INDI_CONST_LEDGER_BYDAY' as table_name ,count(*) from GFAST.TW_INDI_CONST_LEDGER_BYDAY union
select 'TW_INDI_CONST_LEDGER_BYMON' as table_name ,count(*) from GFAST.TW_INDI_CONST_LEDGER_BYMON 


MV_ACL_YF_DCCS
MV_ACT_DPRCTN_DTL_YF
MV_ACT_EXP_DTL_YF
MV_ACT_EXP_JOB_DTL_YF
MV_BUDGET_ACT_SUM_YF
MV_COST_DEPARTMENT_YF
MV_DPRCTN_BUDGET_DTL_YF
MV_EXP_BUDGET_DTL_YF
MV_HDCNT_BUDGET_ACT_SUM_YF
MV_PURCHASE_RECORDS_DETAILS


select 'MV_ACL_YF_DCCS' as table_name ,company_cd,company_nm,count(*) from GFAST.MV_ACL_YF_DCCS group by company_cd,company_nm union all
select 'MV_ACT_DPRCTN_DTL_YF' as table_name ,company_cd,company_nm,count(*) from GFAST.MV_ACT_DPRCTN_DTL_YF group by company_cd,company_nm  union all
select 'MV_ACT_EXP_DTL_YF' as table_name ,company_cd,company_nm,count(*) from GFAST.MV_ACT_EXP_DTL_YF group by company_cd,company_nm  union all
select 'MV_ACT_EXP_JOB_DTL_YF' as table_name ,company_cd,company_nm,count(*) from GFAST.MV_ACT_EXP_JOB_DTL_YF group by company_cd,company_nm  union all
select 'MV_BUDGET_ACT_SUM_YF' as table_name ,company_cd,company_nm,count(*) from GFAST.MV_BUDGET_ACT_SUM_YF group by company_cd,company_nm  union all
select 'MV_COST_DEPARTMENT_YF' as table_name ,company_cd,company_nm,count(*) from GFAST.MV_COST_DEPARTMENT_YF group by company_cd,company_nm  union all
select 'MV_DPRCTN_BUDGET_DTL_YF' as table_name ,company_cd,company_nm,count(*) from GFAST.MV_DPRCTN_BUDGET_DTL_YF group by company_cd,company_nm  union all
select 'MV_EXP_BUDGET_DTL_YF' as table_name ,company_cd,company_nm,count(*) from GFAST.MV_EXP_BUDGET_DTL_YF group by company_cd,company_nm  union all
select 'MV_HDCNT_BUDGET_ACT_SUM_YF' as table_name ,company_cd,company_nm,count(*) from GFAST.MV_HDCNT_BUDGET_ACT_SUM_YF group by company_cd,company_nm 












